"""
=============================================================================
Generative AI Chatbot with RAG
By: Shanmugakumar L  |  B.Tech AI & Data Science

Single-file, run-ready project.

HOW TO RUN:
    1. pip install -r requirements.txt
    2. Create a .env file and add:  OPENAI_API_KEY=sk-your-key-here
    3. python rag_chatbot.py
    4. Open http://localhost:8001/docs

HOW TO USE:
    Step 1 → POST /ingest/text  (add your document/knowledge)
    Step 2 → POST /chat         (ask questions)
    Step 3 → POST /conversation (multi-turn chat with memory)
=============================================================================
"""

# ─────────────────────────────────────────────────────────────────────────────
# SECTION 1 — IMPORTS
# ─────────────────────────────────────────────────────────────────────────────

import os
import uuid
import logging
import warnings
from pathlib import Path
from typing import List, Optional, Iterator, Dict, Any

warnings.filterwarnings("ignore")
logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")
logger = logging.getLogger(__name__)

from dotenv import load_dotenv
load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
CHROMA_DIR     = os.path.join(os.path.dirname(__file__), "chroma_db")
os.makedirs(CHROMA_DIR, exist_ok=True)


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 2 — LLM & EMBEDDINGS
# ─────────────────────────────────────────────────────────────────────────────

def get_embeddings():
    from langchain_openai import OpenAIEmbeddings
    return OpenAIEmbeddings(model="text-embedding-3-small", openai_api_key=OPENAI_API_KEY)

def get_llm(streaming: bool = False):
    from langchain_openai import ChatOpenAI
    return ChatOpenAI(
        model="gpt-4o-mini",
        temperature=0.2,
        streaming=streaming,
        openai_api_key=OPENAI_API_KEY,
    )


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 3 — DOCUMENT INGESTION
# ─────────────────────────────────────────────────────────────────────────────

class DocumentIngester:
    """Load, chunk, and store documents into ChromaDB."""

    def __init__(self):
        from langchain.text_splitter import RecursiveCharacterTextSplitter
        self.splitter = RecursiveCharacterTextSplitter(
            chunk_size=800, chunk_overlap=100,
            separators=["\n\n", "\n", ".", " ", ""],
        )

    def ingest_text(self, text: str, metadata: dict = None,
                    collection_name: str = "default") -> int:
        from langchain_chroma import Chroma
        from langchain_core.documents import Document
        doc    = Document(page_content=text, metadata=metadata or {})
        chunks = self.splitter.split_documents([doc])
        Chroma.from_documents(
            documents=chunks,
            embedding=get_embeddings(),
            persist_directory=CHROMA_DIR,
            collection_name=collection_name,
        )
        logger.info("✅ Ingested %d chunks into '%s'", len(chunks), collection_name)
        return len(chunks)

    def ingest_file(self, file_path: str, collection_name: str = "default") -> int:
        from langchain_chroma import Chroma
        from langchain_community.document_loaders import PyPDFLoader, TextLoader
        ext = Path(file_path).suffix.lower()
        if ext == ".pdf":
            docs = PyPDFLoader(file_path).load()
        elif ext in (".txt", ".md"):
            docs = TextLoader(file_path, encoding="utf-8").load()
        else:
            raise ValueError(f"Unsupported file type: {ext}")
        chunks = self.splitter.split_documents(docs)
        Chroma.from_documents(
            documents=chunks,
            embedding=get_embeddings(),
            persist_directory=CHROMA_DIR,
            collection_name=collection_name,
        )
        logger.info("✅ Ingested %d chunks from '%s'", len(chunks), file_path)
        return len(chunks)


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 4 — RAG RETRIEVER
# ─────────────────────────────────────────────────────────────────────────────

class RAGRetriever:
    def __init__(self, collection_name: str = "default", k: int = 4):
        from langchain_chroma import Chroma
        self.vectorstore = Chroma(
            persist_directory=CHROMA_DIR,
            embedding_function=get_embeddings(),
            collection_name=collection_name,
        )
        self.retriever = self.vectorstore.as_retriever(
            search_type="mmr",
            search_kwargs={"k": k, "fetch_k": k * 3, "lambda_mult": 0.7},
        )

    def get_chunks(self, query: str):
        return self.retriever.invoke(query)

    def format_docs(self, docs) -> str:
        parts = []
        for i, doc in enumerate(docs, 1):
            src  = doc.metadata.get("source", "document")
            page = doc.metadata.get("page", "")
            ref  = f"{src} p.{page}" if page else src
            parts.append(f"[{i}] ({ref})\n{doc.page_content.strip()}")
        return "\n\n---\n\n".join(parts)


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 5 — RAG CHAIN (few-shot + chain-of-thought prompting)
# ─────────────────────────────────────────────────────────────────────────────

# Few-shot examples to guide the LLM
FEW_SHOT_EXAMPLES = [
    {
        "question": "What is RAG?",
        "context":  "RAG stands for Retrieval-Augmented Generation. It combines a retriever with an LLM.",
        "answer":   "Step-by-step: RAG retrieves relevant documents first, then passes them as context to an LLM to generate a grounded, accurate answer. This reduces hallucinations.",
    },
    {
        "question": "What is LangChain?",
        "context":  "LangChain is a framework for building LLM-powered applications with chains, agents, and memory.",
        "answer":   "Step-by-step: LangChain is a Python framework that simplifies building LLM applications by providing abstractions for chains, memory, agents, and tool use.",
    },
]

SYSTEM_PROMPT = (
    "You are a precise, helpful AI assistant. "
    "Answer ONLY based on the provided context. "
    "If the answer is not in the context, say 'I don't have enough information about that.' "
    "Reason step by step before giving your final answer. "
    "Cite [chunk number] when referencing specific information."
)


def build_rag_prompt():
    from langchain_core.prompts import ChatPromptTemplate, FewShotChatMessagePromptTemplate

    example_prompt = ChatPromptTemplate.from_messages([
        ("human", "Question: {question}\nContext: {context}"),
        ("ai",    "Answer: {answer}"),
    ])
    few_shot = FewShotChatMessagePromptTemplate(
        example_prompt=example_prompt,
        examples=FEW_SHOT_EXAMPLES,
    )
    return ChatPromptTemplate.from_messages([
        ("system", SYSTEM_PROMPT),
        few_shot,
        ("human", "Question: {question}\nContext:\n{context}\nAnswer:"),
    ])


class RAGChain:
    def __init__(self, collection_name: str = "default"):
        from langchain_core.output_parsers import StrOutputParser
        from langchain_core.runnables import RunnablePassthrough, RunnableLambda

        self.retriever = RAGRetriever(collection_name)
        self.llm       = get_llm()
        self.prompt    = build_rag_prompt()
        self.chain     = (
            {
                "context":  self.retriever.retriever | RunnableLambda(self.retriever.format_docs),
                "question": RunnablePassthrough(),
            }
            | self.prompt
            | self.llm
            | StrOutputParser()
        )

    def ask(self, question: str) -> Dict[str, Any]:
        chunks = self.retriever.get_chunks(question)
        answer = self.chain.invoke(question)
        return {
            "answer":  answer,
            "sources": [
                {
                    "content": d.page_content[:200],
                    "source":  d.metadata.get("source", ""),
                    "page":    d.metadata.get("page", ""),
                }
                for d in chunks
            ],
        }

    def stream(self, question: str) -> Iterator[str]:
        from langchain_core.output_parsers import StrOutputParser
        from langchain_core.runnables import RunnablePassthrough, RunnableLambda
        llm_s = get_llm(streaming=True)
        chain = (
            {
                "context":  self.retriever.retriever | RunnableLambda(self.retriever.format_docs),
                "question": RunnablePassthrough(),
            }
            | self.prompt
            | llm_s
            | StrOutputParser()
        )
        for token in chain.stream(question):
            yield token


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 6 — MULTI-TURN CONVERSATION MANAGER (LangGraph)
# ─────────────────────────────────────────────────────────────────────────────

class ConversationManager:
    """
    Multi-turn stateful conversations using LangGraph.
    Falls back to simple history tracking if LangGraph is unavailable.
    """

    def __init__(self, collection_name: str = "default"):
        self.collection = collection_name
        self._sessions: Dict[str, list] = {}
        self._graph     = self._build_graph()

    def _build_graph(self):
        try:
            from typing import TypedDict, Annotated
            import operator
            from langchain_core.messages import BaseMessage, HumanMessage, AIMessage
            from langgraph.graph import StateGraph, END
            from langgraph.checkpoint.memory import MemorySaver
            from langchain_core.prompts import ChatPromptTemplate
            from langchain_core.output_parsers import StrOutputParser

            class State(TypedDict):
                messages:   Annotated[List[BaseMessage], operator.add]
                question:   str
                answer:     str
                collection: str

            def retrieve_and_generate(state: State) -> dict:
                retriever = RAGRetriever(state.get("collection", "default"))
                docs      = retriever.get_chunks(state["question"])
                context   = "\n\n---\n\n".join(d.page_content for d in docs) if docs else "No context."

                # Build history string
                history = ""
                for msg in state["messages"][-6:]:
                    role     = "User" if isinstance(msg, HumanMessage) else "Assistant"
                    history += f"{role}: {msg.content}\n"

                prompt = ChatPromptTemplate.from_messages([
                    ("system", SYSTEM_PROMPT),
                    ("human",
                     "Conversation history:\n{history}\n\n"
                     "Context:\n{context}\n\n"
                     "Current question: {question}\n\nAnswer:"),
                ])
                chain  = prompt | get_llm() | StrOutputParser()
                answer = chain.invoke({
                    "history":  history,
                    "context":  context,
                    "question": state["question"],
                })
                return {
                    "answer":   answer,
                    "messages": [HumanMessage(content=state["question"]),
                                 AIMessage(content=answer)],
                }

            builder = StateGraph(State)
            builder.add_node("chat", retrieve_and_generate)
            builder.set_entry_point("chat")
            builder.add_edge("chat", END)
            graph = builder.compile(checkpointer=MemorySaver())
            logger.info("✅ LangGraph conversation graph built.")
            return graph

        except Exception as e:
            logger.warning("LangGraph unavailable (%s). Using fallback.", e)
            return None

    def chat(self, session_id: str, message: str) -> Dict[str, Any]:
        if self._graph:
            try:
                config = {"configurable": {"thread_id": session_id}}
                result = self._graph.invoke(
                    {"messages": [], "question": message,
                     "answer": "", "collection": self.collection},
                    config=config,
                )
                return {
                    "session_id": session_id,
                    "answer":     result["answer"],
                    "turn":       len(result["messages"]) // 2,
                }
            except Exception as e:
                logger.warning("Graph chat failed: %s — using fallback", e)

        # Fallback: simple stateless RAG with local history
        rag     = RAGChain(collection_name=self.collection)
        result  = rag.ask(message)
        history = self._sessions.setdefault(session_id, [])
        history.append({"role": "user",      "content": message})
        history.append({"role": "assistant", "content": result["answer"]})
        return {
            "session_id": session_id,
            "answer":     result["answer"],
            "turn":       len(history) // 2,
            "sources":    result["sources"],
        }

    def get_history(self, session_id: str) -> list:
        return self._sessions.get(session_id, [])


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 7 — FASTAPI APPLICATION
# ─────────────────────────────────────────────────────────────────────────────

from fastapi import FastAPI, HTTPException, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

app = FastAPI(
    title="🤖 Generative AI Chatbot with RAG",
    description=(
        "**By Shanmugakumar L** — B.Tech AI & Data Science\n\n"
        "Domain-specific Q&A chatbot powered by:\n"
        "- 📚 LangChain + ChromaDB for document retrieval\n"
        "- 🧠 GPT-4o-mini with few-shot + chain-of-thought prompting\n"
        "- 🔄 LangGraph for stateful multi-turn conversations\n"
        "- ⚡ FastAPI REST endpoints\n\n"
        "**Quick Start:**\n"
        "1. `POST /ingest/text` — Add your knowledge\n"
        "2. `POST /chat` — Ask questions\n"
        "3. `POST /conversation` — Multi-turn chat\n"
    ),
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"]
)

# Singleton instances
_ingester  = None
_rag_cache: Dict[str, RAGChain]           = {}
_mgr_cache: Dict[str, ConversationManager] = {}

def get_ingester() -> DocumentIngester:
    global _ingester
    if _ingester is None:
        _ingester = DocumentIngester()
    return _ingester

def get_rag(collection: str) -> RAGChain:
    if collection not in _rag_cache:
        _rag_cache[collection] = RAGChain(collection_name=collection)
    return _rag_cache[collection]

def get_manager(collection: str) -> ConversationManager:
    if collection not in _mgr_cache:
        _mgr_cache[collection] = ConversationManager(collection_name=collection)
    return _mgr_cache[collection]

def invalidate(collection: str):
    _rag_cache.pop(collection, None)
    _mgr_cache.pop(collection, None)


# ── Schemas ───────────────────────────────────────────────────────────────────

class TextIngestRequest(BaseModel):
    text:       str = Field(..., example="LangChain is a framework for LLM applications. ChromaDB stores vector embeddings.")
    source:     str = Field(default="user_input", example="my_document")
    collection: str = Field(default="default")

class ChatRequest(BaseModel):
    question:   str = Field(..., example="What is LangChain?")
    collection: str = Field(default="default")

class ConversationRequest(BaseModel):
    session_id: Optional[str] = Field(default=None, example="user_123")
    message:    str = Field(..., example="What is RAG and how does it work?")
    collection: str = Field(default="default")


# ── Endpoints ─────────────────────────────────────────────────────────────────

@app.get("/", tags=["Health"])
def root():
    return {
        "status":    "✅ Running",
        "project":   "Generative AI Chatbot with RAG",
        "author":    "Shanmugakumar L",
        "openai_ok": bool(OPENAI_API_KEY),
        "docs":      "/docs",
        "endpoints": [
            "POST /ingest/text  — Add text knowledge",
            "POST /ingest/file  — Upload PDF/TXT file",
            "POST /chat         — Single-turn Q&A",
            "POST /chat/stream  — Streaming Q&A",
            "POST /conversation — Multi-turn stateful chat",
            "GET  /history/{id} — Conversation history",
        ],
    }


@app.post("/ingest/text", tags=["1 - Ingestion"])
def ingest_text(body: TextIngestRequest):
    """Add text knowledge to the chatbot's memory (ChromaDB)."""
    if not OPENAI_API_KEY:
        raise HTTPException(500, "OPENAI_API_KEY not set in .env file.")
    n = get_ingester().ingest_text(
        body.text,
        metadata={"source": body.source},
        collection_name=body.collection,
    )
    invalidate(body.collection)
    return {"status": "✅ Ingested", "chunks": n, "collection": body.collection}


@app.post("/ingest/file", tags=["1 - Ingestion"])
async def ingest_file(
    file:       UploadFile = File(...),
    collection: str        = Form(default="default"),
):
    """Upload a PDF or TXT file to the chatbot's knowledge base."""
    if not OPENAI_API_KEY:
        raise HTTPException(500, "OPENAI_API_KEY not set in .env file.")
    ext = Path(file.filename).suffix.lower()
    if ext not in (".pdf", ".txt", ".md"):
        raise HTTPException(400, "Only PDF, TXT, and MD files are supported.")
    tmp = f"/tmp/{uuid.uuid4().hex}{ext}"
    with open(tmp, "wb") as f:
        f.write(await file.read())
    try:
        n = get_ingester().ingest_file(tmp, collection_name=collection)
        invalidate(collection)
        return {"status": "✅ Ingested", "filename": file.filename,
                "chunks": n, "collection": collection}
    finally:
        os.unlink(tmp)


@app.post("/chat", tags=["2 - Chat"])
def chat(body: ChatRequest):
    """Ask a single question — returns answer + source chunks."""
    if not OPENAI_API_KEY:
        raise HTTPException(500, "OPENAI_API_KEY not set in .env file.")
    try:
        return get_rag(body.collection).ask(body.question)
    except Exception as e:
        raise HTTPException(500, f"Chat error: {e}")


@app.post("/chat/stream", tags=["2 - Chat"])
def chat_stream(body: ChatRequest):
    """Ask a question with streaming token-by-token response."""
    if not OPENAI_API_KEY:
        raise HTTPException(500, "OPENAI_API_KEY not set in .env file.")
    def gen():
        try:
            for token in get_rag(body.collection).stream(body.question):
                yield token
        except Exception as e:
            yield f"\n\n[ERROR: {e}]"
    return StreamingResponse(gen(), media_type="text/plain")


@app.post("/conversation", tags=["3 - Multi-turn"])
def conversation(body: ConversationRequest):
    """
    Multi-turn stateful conversation.
    Pass the same session_id across turns to maintain memory.
    """
    if not OPENAI_API_KEY:
        raise HTTPException(500, "OPENAI_API_KEY not set in .env file.")
    session_id = body.session_id or str(uuid.uuid4())
    try:
        result = get_manager(body.collection).chat(session_id, body.message)
        return result
    except Exception as e:
        raise HTTPException(500, f"Conversation error: {e}")


@app.get("/history/{session_id}", tags=["3 - Multi-turn"])
def get_history(session_id: str, collection: str = "default"):
    """Get the full conversation history for a session."""
    history = get_manager(collection).get_history(session_id)
    return {"session_id": session_id, "history": history, "turns": len(history) // 2}


@app.delete("/session/{session_id}", tags=["3 - Multi-turn"])
def clear_session(session_id: str, collection: str = "default"):
    """Clear a conversation session's memory."""
    manager = get_manager(collection)
    if session_id in manager._sessions:
        del manager._sessions[session_id]
    return {"status": "✅ Cleared", "session_id": session_id}


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 8 — ENTRY POINT
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import uvicorn

    print("""
╔══════════════════════════════════════════════════════════════╗
║        Generative AI Chatbot with RAG                        ║
║        By: Shanmugakumar L  |  B.Tech AI & Data Science      ║
╠══════════════════════════════════════════════════════════════╣
║   API Docs  →  http://localhost:8001/docs                    ║
║   Health    →  http://localhost:8001/                        ║
╠══════════════════════════════════════════════════════════════╣
║   Quick Start:                                               ║
║   1. POST /ingest/text  → Add your knowledge                 ║
║   2. POST /chat         → Ask questions                      ║
║   3. POST /conversation → Multi-turn chat                    ║
╚══════════════════════════════════════════════════════════════╝
    """)

    if not OPENAI_API_KEY:
        print("⚠️  WARNING: OPENAI_API_KEY not found!")
        print("   Create a .env file in the same folder with:")
        print("   OPENAI_API_KEY=sk-your-key-here\n")

    uvicorn.run(app, host="0.0.0.0", port=8001)
