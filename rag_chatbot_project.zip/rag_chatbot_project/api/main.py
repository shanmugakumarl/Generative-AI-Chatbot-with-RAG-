"""
main.py — FastAPI app for the Generative AI Chatbot with RAG.

Endpoints
---------
GET  /                         Health check
POST /ingest/text              Ingest plain text into ChromaDB
POST /ingest/file              Upload & ingest PDF or TXT file
POST /chat                     Single-turn RAG Q&A
POST /chat/stream              Streaming single-turn Q&A
POST /conversation             Multi-turn conversation (LangGraph)
GET  /history/{session_id}     Get conversation history
DELETE /session/{session_id}   Clear a session
GET  /collections              List available collections
"""

import os, uuid, logging, asyncio
from typing import Optional
from io import BytesIO
from pathlib import Path
from dotenv import load_dotenv
load_dotenv()

from fastapi import FastAPI, HTTPException, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

from api.rag_pipeline     import DocumentIngester, RAGChain
from api.conversation_graph import ConversationManager

logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")
logger = logging.getLogger(__name__)

OPENAI_KEY = os.getenv("OPENAI_API_KEY", "")

# ── App ───────────────────────────────────────────────────────────────────────
app = FastAPI(
    title="Generative AI Chatbot with RAG",
    description=(
        "Domain-specific Q&A chatbot powered by LangChain, LangGraph, "
        "ChromaDB, and GPT-4o-mini. Supports multi-turn stateful conversations."
    ),
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Singleton managers
_ingester   = None
_rag_chains: dict = {}
_managers:   dict = {}

def get_ingester() -> DocumentIngester:
    global _ingester
    if _ingester is None:
        _ingester = DocumentIngester()
    return _ingester

def get_rag_chain(collection: str) -> RAGChain:
    if collection not in _rag_chains:
        _rag_chains[collection] = RAGChain(collection_name=collection)
    return _rag_chains[collection]

def get_manager(collection: str) -> ConversationManager:
    if collection not in _managers:
        _managers[collection] = ConversationManager(collection_name=collection)
    return _managers[collection]


# ── Schemas ───────────────────────────────────────────────────────────────────
class TextIngestRequest(BaseModel):
    text:       str  = Field(..., example="LangChain is a framework for LLM apps.")
    source:     str  = Field(default="user_input", example="my_doc")
    collection: str  = Field(default="default")

class ChatRequest(BaseModel):
    question:   str  = Field(..., example="What is RAG?")
    collection: str  = Field(default="default")

class ConversationRequest(BaseModel):
    session_id: Optional[str] = Field(default=None)
    message:    str  = Field(..., example="What is LangChain?")
    collection: str  = Field(default="default")


# ── Routes ────────────────────────────────────────────────────────────────────
@app.get("/", tags=["Health"])
def root():
    return {
        "status":    "running",
        "project":   "Generative AI Chatbot with RAG",
        "author":    "Shanmugakumar L",
        "openai_ok": bool(OPENAI_KEY),
        "docs":      "/docs",
    }


@app.post("/ingest/text", tags=["Ingestion"])
def ingest_text(body: TextIngestRequest):
    if not OPENAI_KEY:
        raise HTTPException(500, "OPENAI_API_KEY not configured.")
    n = get_ingester().ingest_text(
        body.text,
        metadata={"source": body.source},
        collection_name=body.collection,
    )
    # Invalidate cached chains for this collection
    _rag_chains.pop(body.collection, None)
    _managers.pop(body.collection, None)
    return {"status": "ingested", "chunks": n, "collection": body.collection}


@app.post("/ingest/file", tags=["Ingestion"])
async def ingest_file(
    file:       UploadFile = File(...),
    collection: str        = Form(default="default"),
):
    if not OPENAI_KEY:
        raise HTTPException(500, "OPENAI_API_KEY not configured.")

    ext = Path(file.filename).suffix.lower()
    if ext not in (".pdf", ".txt", ".md"):
        raise HTTPException(400, "Only PDF, TXT, and MD files are supported.")

    # Save temp file
    tmp_path = f"/tmp/{uuid.uuid4().hex}{ext}"
    content  = await file.read()
    with open(tmp_path, "wb") as f:
        f.write(content)

    try:
        n = get_ingester().ingest_file(tmp_path, collection_name=collection)
        _rag_chains.pop(collection, None)
        _managers.pop(collection, None)
        return {"status": "ingested", "filename": file.filename,
                "chunks": n, "collection": collection}
    finally:
        os.unlink(tmp_path)


@app.post("/chat", tags=["Chat"])
def chat(body: ChatRequest):
    if not OPENAI_KEY:
        raise HTTPException(500, "OPENAI_API_KEY not configured.")
    try:
        result = get_rag_chain(body.collection).ask(body.question)
        return result
    except Exception as e:
        logger.error("Chat error: %s", e)
        raise HTTPException(500, str(e))


@app.post("/chat/stream", tags=["Chat"])
def chat_stream(body: ChatRequest):
    if not OPENAI_KEY:
        raise HTTPException(500, "OPENAI_API_KEY not configured.")

    def token_gen():
        try:
            for token in get_rag_chain(body.collection).stream(body.question):
                yield token
        except Exception as e:
            yield f"\n\n[ERROR: {e}]"

    return StreamingResponse(token_gen(), media_type="text/plain")


@app.post("/conversation", tags=["Multi-turn"])
def conversation(body: ConversationRequest):
    if not OPENAI_KEY:
        raise HTTPException(500, "OPENAI_API_KEY not configured.")
    session_id = body.session_id or str(uuid.uuid4())
    try:
        result = get_manager(body.collection).chat(session_id, body.message)
        return result
    except Exception as e:
        logger.error("Conversation error: %s", e)
        raise HTTPException(500, str(e))


@app.get("/history/{session_id}", tags=["Multi-turn"])
def get_history(session_id: str, collection: str = "default"):
    history = get_manager(collection).get_history(session_id)
    return {"session_id": session_id, "history": history, "turns": len(history) // 2}


@app.delete("/session/{session_id}", tags=["Multi-turn"])
def clear_session(session_id: str, collection: str = "default"):
    manager = get_manager(collection)
    if session_id in manager._sessions:
        del manager._sessions[session_id]
    return {"status": "cleared", "session_id": session_id}
