"""
rag_pipeline.py — Core RAG pipeline using LangChain + ChromaDB.

Features
--------
- Ingest PDF / TXT / plain text documents into ChromaDB
- Retrieve top-k relevant chunks via MMR (Maximal Marginal Relevance)
- Answer questions with GPT-4o-mini using few-shot + chain-of-thought prompting
- Streaming support
"""

import os
import logging
from pathlib import Path
from typing import List, Optional, Iterator

from dotenv import load_dotenv
load_dotenv()

from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_community.document_loaders import PyPDFLoader, TextLoader, DirectoryLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_chroma import Chroma
from langchain_core.documents import Document
from langchain_core.prompts import ChatPromptTemplate, FewShotChatMessagePromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough, RunnableLambda

logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")
logger = logging.getLogger(__name__)

CHROMA_DIR  = os.path.join(os.path.dirname(__file__), "..", "vectorstore", "chroma_db")
OPENAI_KEY  = os.getenv("OPENAI_API_KEY", "")


# ── Embeddings & LLM ──────────────────────────────────────────────────────────
def get_embeddings() -> OpenAIEmbeddings:
    return OpenAIEmbeddings(model="text-embedding-3-small", openai_api_key=OPENAI_KEY)

def get_llm(streaming: bool = False) -> ChatOpenAI:
    return ChatOpenAI(
        model="gpt-4o-mini",
        temperature=0.2,
        streaming=streaming,
        openai_api_key=OPENAI_KEY,
    )


# ── Document ingestion ────────────────────────────────────────────────────────
class DocumentIngester:
    """Load, chunk, and store documents in ChromaDB."""

    def __init__(self):
        self.splitter = RecursiveCharacterTextSplitter(
            chunk_size=800,
            chunk_overlap=100,
            separators=["\n\n", "\n", ".", " ", ""],
        )
        self.embeddings = get_embeddings()

    def _load_file(self, path: str) -> List[Document]:
        ext = Path(path).suffix.lower()
        if ext == ".pdf":
            return PyPDFLoader(path).load()
        elif ext in (".txt", ".md"):
            return TextLoader(path, encoding="utf-8").load()
        else:
            raise ValueError(f"Unsupported file type: {ext}")

    def ingest_file(self, file_path: str, collection_name: str = "default") -> int:
        docs   = self._load_file(file_path)
        chunks = self.splitter.split_documents(docs)
        logger.info("Ingesting %d chunks from '%s' …", len(chunks), file_path)

        Chroma.from_documents(
            documents=chunks,
            embedding=self.embeddings,
            persist_directory=CHROMA_DIR,
            collection_name=collection_name,
        )
        logger.info("✅ Ingested %d chunks into collection '%s'", len(chunks), collection_name)
        return len(chunks)

    def ingest_text(self, text: str, metadata: dict = None,
                    collection_name: str = "default") -> int:
        doc    = Document(page_content=text, metadata=metadata or {})
        chunks = self.splitter.split_documents([doc])

        Chroma.from_documents(
            documents=chunks,
            embedding=self.embeddings,
            persist_directory=CHROMA_DIR,
            collection_name=collection_name,
        )
        logger.info("✅ Ingested %d chunks (text) into '%s'", len(chunks), collection_name)
        return len(chunks)

    def ingest_directory(self, dir_path: str, collection_name: str = "default") -> int:
        total = 0
        for f in Path(dir_path).rglob("*"):
            if f.suffix.lower() in (".pdf", ".txt", ".md"):
                total += self.ingest_file(str(f), collection_name)
        return total


# ── Retriever ─────────────────────────────────────────────────────────────────
class RAGRetriever:
    def __init__(self, collection_name: str = "default", k: int = 4):
        self.embeddings  = get_embeddings()
        self.vectorstore = Chroma(
            persist_directory=CHROMA_DIR,
            embedding_function=self.embeddings,
            collection_name=collection_name,
        )
        # MMR balances relevance and diversity
        self.retriever = self.vectorstore.as_retriever(
            search_type="mmr",
            search_kwargs={"k": k, "fetch_k": k * 3, "lambda_mult": 0.7},
        )

    def get_relevant_chunks(self, query: str) -> List[Document]:
        return self.retriever.invoke(query)

    def format_docs(self, docs: List[Document]) -> str:
        parts = []
        for i, doc in enumerate(docs, 1):
            src  = doc.metadata.get("source", "document")
            page = doc.metadata.get("page", "")
            ref  = f"{src} p.{page}" if page else src
            parts.append(f"[{i}] ({ref})\n{doc.page_content.strip()}")
        return "\n\n---\n\n".join(parts)


# ── Prompt with few-shot + chain-of-thought ───────────────────────────────────
FEW_SHOT_EXAMPLES = [
    {
        "question": "What is RAG?",
        "context":  "Retrieval-Augmented Generation (RAG) combines a retriever with an LLM to answer questions using external knowledge.",
        "answer":   (
            "Let me reason step by step.\n"
            "RAG stands for Retrieval-Augmented Generation. "
            "It works by first retrieving relevant documents from a knowledge base, "
            "then feeding those documents as context to a language model to generate a grounded answer. "
            "This reduces hallucinations and keeps answers factual."
        ),
    },
    {
        "question": "What is LangChain?",
        "context":  "LangChain is a framework for building LLM-powered applications with chains, agents, and memory.",
        "answer":   (
            "Step-by-step: LangChain is an open-source Python framework "
            "that simplifies building applications powered by large language models. "
            "It provides abstractions for chains, memory, agents, and tool use, "
            "enabling developers to compose complex LLM workflows easily."
        ),
    },
]

example_prompt = ChatPromptTemplate.from_messages([
    ("human", "Question: {question}\nContext: {context}"),
    ("ai",    "Answer: {answer}"),
])

few_shot_prompt = FewShotChatMessagePromptTemplate(
    example_prompt=example_prompt,
    examples=FEW_SHOT_EXAMPLES,
)

SYSTEM_PROMPT = (
    "You are a precise, helpful AI assistant. "
    "Answer ONLY based on the provided context. "
    "If the answer is not in the context, say so clearly. "
    "Reason step by step before giving your final answer. "
    "Cite [chunk number] when referencing specific information."
)

rag_prompt = ChatPromptTemplate.from_messages([
    ("system", SYSTEM_PROMPT),
    few_shot_prompt,
    ("human", "Question: {question}\nContext:\n{context}\nAnswer:"),
])


# ── RAG Chain ─────────────────────────────────────────────────────────────────
class RAGChain:
    def __init__(self, collection_name: str = "default", k: int = 4):
        self.retriever = RAGRetriever(collection_name, k)
        self.llm       = get_llm()
        self.chain     = self._build_chain()

    def _build_chain(self):
        return (
            {
                "context":  self.retriever.retriever | RunnableLambda(self.retriever.format_docs),
                "question": RunnablePassthrough(),
            }
            | rag_prompt
            | self.llm
            | StrOutputParser()
        )

    def ask(self, question: str) -> dict:
        """Retrieve + answer, returning answer + source chunks."""
        chunks = self.retriever.get_relevant_chunks(question)
        answer = self.chain.invoke(question)
        return {
            "answer":  answer,
            "sources": [
                {
                    "content": d.page_content[:200],
                    "source":  d.metadata.get("source", ""),
                    "page":    d.metadata.get("page", ""),
                }
                for d in chunks
            ],
        }

    def stream(self, question: str) -> Iterator[str]:
        """Streaming version."""
        llm_stream = get_llm(streaming=True)
        chain = (
            {
                "context":  self.retriever.retriever | RunnableLambda(self.retriever.format_docs),
                "question": RunnablePassthrough(),
            }
            | rag_prompt
            | llm_stream
            | StrOutputParser()
        )
        for token in chain.stream(question):
            yield token


# ── CLI smoke-test ────────────────────────────────────────────────────────────
if __name__ == "__main__":
    if not OPENAI_KEY:
        print("⚠️  Set OPENAI_API_KEY in your .env file to run this test.")
    else:
        ingester = DocumentIngester()
        ingester.ingest_text(
            "LangChain is a framework for building LLM applications. "
            "ChromaDB is an open-source vector database for embeddings. "
            "RAG combines retrieval with generation for grounded answers.",
            metadata={"source": "intro_doc"},
            collection_name="test",
        )
        rag = RAGChain(collection_name="test")
        result = rag.ask("What is ChromaDB?")
        print("Answer:", result["answer"])
