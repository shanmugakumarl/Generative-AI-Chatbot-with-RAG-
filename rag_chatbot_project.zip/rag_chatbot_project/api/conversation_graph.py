"""
conversation_graph.py — Multi-turn stateful conversation using LangGraph.

Graph nodes
-----------
1. retrieve       — fetch relevant chunks from ChromaDB
2. grade_docs     — filter irrelevant chunks (hallucination guard)
3. generate       — produce answer with context + history
4. check_answer   — verify answer addresses the question (optional guard)

State is persisted across turns so the bot remembers previous messages.
"""

import os
import logging
from typing import TypedDict, List, Annotated, Sequence, Literal
from dotenv import load_dotenv
load_dotenv()

from langchain_core.messages import BaseMessage, HumanMessage, AIMessage, SystemMessage
from langchain_core.documents import Document
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
import operator

try:
    from langgraph.graph import StateGraph, END
    from langgraph.checkpoint.memory import MemorySaver
    LANGGRAPH_AVAILABLE = True
except ImportError:
    LANGGRAPH_AVAILABLE = False

from api.rag_pipeline import RAGRetriever, get_llm

logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")
logger = logging.getLogger(__name__)

OPENAI_KEY = os.getenv("OPENAI_API_KEY", "")


# ── Graph State ───────────────────────────────────────────────────────────────
class ConversationState(TypedDict):
    messages:    Annotated[List[BaseMessage], operator.add]
    question:    str
    documents:   List[Document]
    answer:      str
    collection:  str
    turn:        int


# ── Node functions ────────────────────────────────────────────────────────────
def node_retrieve(state: ConversationState) -> dict:
    logger.info("[node_retrieve] query='%s'", state["question"][:60])
    retriever = RAGRetriever(collection_name=state.get("collection", "default"), k=4)
    docs      = retriever.get_relevant_chunks(state["question"])
    return {"documents": docs}


def node_grade_docs(state: ConversationState) -> dict:
    """Keep only chunks that are somewhat relevant (keyword heuristic)."""
    question = state["question"].lower()
    keywords = set(question.split())
    filtered = []
    for doc in state["documents"]:
        content_words = set(doc.page_content.lower().split())
        overlap = len(keywords & content_words)
        if overlap >= 1:   # at least 1 keyword overlap
            filtered.append(doc)
    if not filtered:
        filtered = state["documents"]   # fallback: keep all
    logger.info("[node_grade_docs] kept %d / %d chunks", len(filtered), len(state["documents"]])
    return {"documents": filtered}


def node_generate(state: ConversationState) -> dict:
    """Generate answer using context + conversation history."""
    llm   = get_llm()
    docs  = state["documents"]
    context = "\n\n---\n\n".join(d.page_content for d in docs) if docs else "No context available."

    # Build history string (last 6 messages)
    history_msgs = state["messages"][-6:] if len(state["messages"]) > 6 else state["messages"]
    history_str  = ""
    for msg in history_msgs:
        role = "User" if isinstance(msg, HumanMessage) else "Assistant"
        history_str += f"{role}: {msg.content}\n"

    prompt = ChatPromptTemplate.from_messages([
        ("system",
         "You are a knowledgeable AI assistant. "
         "Use the provided context and conversation history to answer accurately. "
         "Reason step-by-step. If unsure, say so. Cite [chunk] when possible."),
        ("human",
         "Conversation history:\n{history}\n\n"
         "Context:\n{context}\n\n"
         "Current question: {question}\n\nAnswer:"),
    ])

    chain  = prompt | llm | StrOutputParser()
    answer = chain.invoke({
        "history":  history_str,
        "context":  context,
        "question": state["question"],
    })

    new_messages = [
        HumanMessage(content=state["question"]),
        AIMessage(content=answer),
    ]
    return {"answer": answer, "messages": new_messages, "turn": state.get("turn", 0) + 1}


# ── Build the graph ───────────────────────────────────────────────────────────
def build_conversation_graph():
    if not LANGGRAPH_AVAILABLE:
        logger.warning("LangGraph not available; using simple fallback.")
        return None

    builder = StateGraph(ConversationState)
    builder.add_node("retrieve",   node_retrieve)
    builder.add_node("grade_docs", node_grade_docs)
    builder.add_node("generate",   node_generate)

    builder.set_entry_point("retrieve")
    builder.add_edge("retrieve",   "grade_docs")
    builder.add_edge("grade_docs", "generate")
    builder.add_edge("generate",   END)

    memory = MemorySaver()
    return builder.compile(checkpointer=memory)


# ── Conversation Manager (facade) ─────────────────────────────────────────────
class ConversationManager:
    """
    High-level interface for multi-turn RAG conversations.
    Falls back to stateless RAG if LangGraph is unavailable.
    """

    def __init__(self, collection_name: str = "default"):
        self.collection = collection_name
        self.graph      = build_conversation_graph()
        self._sessions: dict = {}   # session_id → message history (fallback)

    def chat(self, session_id: str, user_message: str) -> dict:
        if self.graph is not None:
            return self._graph_chat(session_id, user_message)
        return self._fallback_chat(session_id, user_message)

    def _graph_chat(self, session_id: str, user_message: str) -> dict:
        config = {"configurable": {"thread_id": session_id}}
        state  = {
            "messages":   [],
            "question":   user_message,
            "documents":  [],
            "answer":     "",
            "collection": self.collection,
            "turn":       0,
        }
        result = self.graph.invoke(state, config=config)
        return {
            "session_id": session_id,
            "answer":     result["answer"],
            "turn":       result.get("turn", 1),
            "sources":    [
                {"content": d.page_content[:200], "source": d.metadata.get("source", "")}
                for d in result.get("documents", [])
            ],
        }

    def _fallback_chat(self, session_id: str, user_message: str) -> dict:
        """Simple stateless fallback."""
        from api.rag_pipeline import RAGChain
        rag    = RAGChain(collection_name=self.collection)
        result = rag.ask(user_message)
        history = self._sessions.setdefault(session_id, [])
        history.append({"role": "user",      "content": user_message})
        history.append({"role": "assistant", "content": result["answer"]})
        return {"session_id": session_id, "answer": result["answer"],
                "turn": len(history) // 2, "sources": result["sources"]}

    def get_history(self, session_id: str) -> list:
        if self.graph is not None:
            config = {"configurable": {"thread_id": session_id}}
            try:
                state = self.graph.get_state(config).values
                return [{"role": "user" if isinstance(m, HumanMessage) else "assistant",
                         "content": m.content} for m in state.get("messages", [])]
            except Exception:
                return []
        return self._sessions.get(session_id, [])


# ── CLI test ──────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    if not OPENAI_KEY:
        print("⚠️  Set OPENAI_API_KEY in .env to test.")
    else:
        from api.rag_pipeline import DocumentIngester
        ingester = DocumentIngester()
        ingester.ingest_text(
            "Python is a high-level programming language. "
            "LangChain is used to build LLM applications. "
            "ChromaDB stores vector embeddings for semantic search.",
            collection_name="demo",
        )
        manager = ConversationManager(collection_name="demo")
        for q in ["What is Python?", "How does LangChain relate to it?"]:
            r = manager.chat("session_001", q)
            print(f"Q: {q}\nA: {r['answer']}\n")
